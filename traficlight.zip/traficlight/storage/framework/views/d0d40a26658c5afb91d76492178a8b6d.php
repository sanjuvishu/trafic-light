<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Street Light Test</title>

        <!-- Fonts -->
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
        <!-- Styles -->
        <style>
            #dif1{
                width:60px;
                height:70px;
                border-radius:50%;
                background:red;
                border: 2px solid;
                display: inline-block;
                text-align:center;
                font-weight:bold;
                padding: 20px;
            }
            #dif2{
                width:60px;
                height:70px;
                border-radius:50%;
                background:green;
                border: 2px solid;
                display: inline-block;
                text-align:center;
                font-weight:bold;
                padding: 20px;
            }
            #dif3{
                width:60px;
                height:70px;
                border-radius:50%;
                background:red;
                border: 2px solid;
                display: inline-block;
                text-align:center;
                font-weight:bold;
                padding: 20px;
            }
            #dif4{
                width:60px;
                height:70px;
                border-radius:50%;
                background:red;
                border: 2px solid;
                display: inline-block;
                text-align:center;
                font-weight:bold;
                padding: 20px;
            }

            .txtSignal{
                margin-top: 16px;
                position: absolute;
                margin-left: 20px;
            }
        </style>
    </head>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">
        <div class="container">
            <div class=""> <h1> Working Of the Street Light </h1></div>
            
            <div class="rows d-flex">
                <div class="col-xs-2 col-md-2 col-lg-2  mt-2 d-inline-block">
                    <div id="dif1"> A </div>
                    <span>
                        <input type="text" size="1" id="a" class="dif1">
                    </span>
                </div>
                
                <div class="col-xs-2 col-md-2 col-lg-2 mt-2 d-inline-block">
                    <div id="dif2"> B </div>
                    <span><input type="text" size="1" id="b" class="dif2"></span>
                </div>

                <div class="col-xs-2 col-md-2 col-lg-2 mt-2 ">
                    <div id="dif3"> C </div>
                    <span><input type="text" size="1" id="c" class="dif3"></span>
                </div>

                <div class="col-xs-2 col-md-2 col-lg-2 mt-2 d-inline-block">
                    <div id="dif4"> D </div>
                    <span><input type="text" size="1" id="d" class="dif4"></span>
                </div>
            </div>

            <div class="row  mt-4">
                <div class="col-xs-2 col-md-2 col-lg-2">
                    Geern Light Interval:  <input type="text" size="5" name="grnlight" id="grn" class="dif5">
                </div>
                
                <div class="col-xs-2 col-md-2 col-lg-2">
                    Yellow Light Interval: <input type="text" size="5" name="ylwlight" id="ylw" class="dif2">
                </div>
            </div>

            <div class="row mt-2 gap-3">
                <div class="col-xs-2 col-md-2 col-lg-2">
                    <span><button type="button" id="start" class="btn btn-primary btn-lg"> Start </button></span>
                    <span><button type="button" id="stop" class="btn btn btn-danger btn-lg"> Stop </button></span>
                </div>
            </div>

        </div>

<script>
    $(document).ready(function(){
        $('#start').on('click', function(){
            //alert('Clicked Me..');
            var allFilled = true;
            var data = {};

            /** Get Values of colors */
            var aVal = $("#a").val();
            var aClsName = $("#a").attr('class');
            data[aVal] = aClsName;
            
            var bVal = $("#b").val();
            var bClsName = $("#b").attr('class');
            data[bVal] = bClsName;


            var cVal = $("#c").val();
            var cClsName = $("#c").attr('class');
            data[cVal] = cClsName;


            var dVal = $("#d").val();
            var dClsName = $("#d").attr('class');
            data[dVal] = dClsName;
            
            if(aVal == '' || bVal == '' || cVal == '' || dVal == ''){
                allFilled = false;
            }

            if(allFilled == true){
                var green_intv = parseInt($("#grn").val()); 
                var yellow_intv = parseInt($("#ylw").val());
                
                var greaterValue;
                var smallerValue;
                var greaterId;
                var smallerId;

                if (green_intv > yellow_intv) {
                    greaterValue = green_intv * 1000;
                    greaterId = 'green';
                    smallerValue = yellow_intv * 1000;
                    smallerId = 'yellow';
                } else {
                    greaterValue = yellow_intv * 1000;
                    greaterId = 'yellow';
                    smallerValue = green_intv * 1000;
                    smallerId = 'green';
                }

                var dataArray = Object.entries(data).map(([key, value]) => ({
                    key,
                    value
                }));
                var dataIndex = 0;
                var flag = 'true'
                var old_color = '';
                var old_color_array = [];
                var old_id = '';

                function endtime() {

                    if ((old_color_array.includes('green')) && (old_color_array.includes('yellow'))) {
                        dataIndex++;
                    }
                    if (dataIndex >= dataArray.length) {
                        dataIndex = 0;
                    }
                }

                function myFunction(color) {
                    if ((old_color_array.includes('green')) && (old_color_array.includes('yellow'))) {
                        $('#' + old_id).css('background-color', 'red');
                        old_color_array.length = 0;
                        old_id = '';
                    }
                    if (old_color !== color) {
                        old_color_array.push(color);
                        var id = dataArray[dataIndex].value;
                        old_id = id;
                        console.log(dataArray)
                        $('#' + id).css('background-color', color);
                    }
                    old_color = color;
                }

                function setDynamicIntervals() {
                    intervalId = setInterval(function() {
                        if (flag) {
                            myFunction(smallerId);
                            setTimeout(function() {
                                endtime()
                                flag = false;
                            }, smallerValue);
                        } else {
                            myFunction(greaterId);
                            setTimeout(function() {
                                endtime()
                                flag = true;
                            }, greaterValue);
                        }
                    }, flag ? smallerValue : greaterValue);
                }


                setDynamicIntervals();
                //alert(green_intv);
                //alert(yellow_intv);
            }else{
                alert("Please fill all values first.");
                $("#a").focus();
                return false;
            }
            
        });
        
        $("#stop").click(function() {
            $('#dif1').css('background-color', 'red');
            $('#dif2').css('background-color', 'red');
            $('#dif3').css('background-color', 'red');
            $('#dif4').css('background-color', 'red');
        });
    });
</script>

    </body>
</html>
<?php /**PATH E:\New_XAMPP\htdocs\traficlight\resources\views/welcome.blade.php ENDPATH**/ ?>